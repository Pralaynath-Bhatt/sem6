package com.example.filetransferbluetooth;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

public class MainActivity extends Activity {

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_SELECT_FILE = 2;

    private BluetoothAdapter bluetoothAdapter;
    private ArrayAdapter<String> deviceListAdapter;
    private String selectedDeviceAddress;
    private Uri selectedFileUri;

    private TextView selectedDeviceText;
    private TextView selectedFileText;
    private Button sendFileBtn;

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button enableBluetoothBtn = findViewById(R.id.enableBluetoothBtn);
        selectedDeviceText = findViewById(R.id.selectedDeviceText);
        ListView devicesListView = findViewById(R.id.devicesListView);
        Button selectFileBtn = findViewById(R.id.selectFileBtn);
        selectedFileText = findViewById(R.id.selectedFileText);
        sendFileBtn = findViewById(R.id.sendFileBtn);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        deviceListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        devicesListView.setAdapter(deviceListAdapter);

        // Enable Bluetooth
        enableBluetoothBtn.setOnClickListener(view -> {
            if (bluetoothAdapter == null) {
                Toast.makeText(this, "Bluetooth not supported on this device", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            } else {
                Toast.makeText(this, "Bluetooth is already enabled", Toast.LENGTH_SHORT).show();
                listPairedDevices();
            }
        });

        // List paired Bluetooth devices
        devicesListView.setOnItemClickListener((adapterView, view, position, id) -> {
            String deviceInfo = ((TextView) view).getText().toString();
            selectedDeviceAddress = deviceInfo.substring(deviceInfo.length() - 17);
            selectedDeviceText.setText("Selected Device: " + selectedDeviceAddress);
        });

        // Select a file
        selectFileBtn.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(Intent.createChooser(intent, "Select File"), REQUEST_SELECT_FILE);
        });

        // Send file
        sendFileBtn.setOnClickListener(view -> {
            if (selectedDeviceAddress == null || selectedFileUri == null) {
                Toast.makeText(this, "Please select a device and file first", Toast.LENGTH_SHORT).show();
                return;
            }
            sendFile(selectedDeviceAddress, selectedFileUri);
        });

        // Register Bluetooth discovery receiver
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(bluetoothReceiver, filter);
    }

    @SuppressLint("MissingPermission")
    private void listPairedDevices() {
        @SuppressLint("MissingPermission") Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        deviceListAdapter.clear();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                deviceListAdapter.add(device.getName() + "\n" + device.getAddress());
            }
        } else {
            deviceListAdapter.add("No paired devices found");
        }
    }

    private void sendFile(String deviceAddress, Uri fileUri) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_STREAM, fileUri);
        intent.setPackage("com.android.bluetooth");
        startActivity(Intent.createChooser(intent, "Send File"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ENABLE_BT && resultCode == RESULT_OK) {
            Toast.makeText(this, "Bluetooth enabled", Toast.LENGTH_SHORT).show();
            listPairedDevices();
        } else if (requestCode == REQUEST_SELECT_FILE && resultCode == RESULT_OK && data != null) {
            selectedFileUri = data.getData();
            selectedFileText.setText("Selected File: " + selectedFileUri.getPath());
        }
    }

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) {
                    deviceListAdapter.add(device.getName() + "\n" + device.getAddress());
                }
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(bluetoothReceiver);
    }
}
